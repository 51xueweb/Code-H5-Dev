window.onload = function() {
  document
  .getElementsByTagName('body')[0]
  .innerHTML += "<div class='nav'>" + 
                    "<ul><li><a href='index.html'>曲线图表</a></li>"+
                    "<li><a href='index2.html'>面积图表</a></li>"+
                    "<li><a href='index3.html'>水平柱状图表</a></li>"+
                    "<li><a href='index4.html'>竖直柱状图表</a></li>"+
                    "<li><a href='index5.html'>饼状图</a></li>"+
                  "</ul>"+
                "</div>" ;
}