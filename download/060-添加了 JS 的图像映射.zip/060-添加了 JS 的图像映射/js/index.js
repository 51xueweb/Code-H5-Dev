function writeText(txt) {
  document.getElementById("desc").innerHTML=txt
}