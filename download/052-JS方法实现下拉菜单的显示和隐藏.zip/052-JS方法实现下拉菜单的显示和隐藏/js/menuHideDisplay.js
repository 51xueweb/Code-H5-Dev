//显示
function showSub(li){
  var subMenu = li.getElementsByTagName('ul')[0];
  subMenu.style.display = 'block';
}
//隐藏
function hideSub(li){
  var subMenu = li.getElementsByTagName('ul')[0];
  subMenu.style.display = 'none';
}